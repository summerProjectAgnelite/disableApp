package com.example.vikasmaurya.disableapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    var emailEditText: EditText? = null
    var passwordEditText: EditText? = null
    val mAuth= FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)

        if (mAuth.currentUser != null) {

            logIn()
        }

    }


    fun goClicked(view: View){
        //check if we login the user
        mAuth.signInWithEmailAndPassword(emailEditText?.text.toString(), passwordEditText?.text.toString())
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        //  Log.d(FragmentActivity.TAG, "signInWithEmail:success")
                        // val user = mAuth.currentUser
                        //updateUI(user)
                        logIn()
                    } else {
                        // If sign in fails, display a message to the user.
                        // Log.w(FragmentActivity.TAG, "signInWithEmail:failure", task.exception)
                        //  Toast.makeText(this@EmailPasswordActivity, "Authentication failed.",
                        //       Toast.LENGTH_SHORT).show()
                        //updateUI(null)



                        //sign up the user
                        mAuth.createUserWithEmailAndPassword(emailEditText?.text.toString(), passwordEditText?.text.toString())
                                .addOnCompleteListener(this){task ->
                                    if(task.isSuccessful){
                                        //add to database
                                        logIn()
                                    }
                                    else{
                                        Toast.makeText(this,"Login failed try again", Toast.LENGTH_SHORT).show()
                                    }

                                }

                    }

                }



    }
    fun logIn(){
        //move to next activity
        val intent = Intent(this,menuActivity::class.java)
        startActivity(intent)

    }



}
